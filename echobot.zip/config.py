#!/usr/bin/env python3
# Copyright (c) Microsoft Corporation. All rights reserved.
# Licensed under the MIT License.

import os

class DefaultConfig:
    """ Bot Configuration """

    PORT = 3978
    APP_ID = os.environ.get("MicrosoftAppId", "dc8e9238-cb7a-41e2-bd12-10db9f8c5408")
    APP_PASSWORD = os.environ.get("MicrosoftAppPassword", "m1O8Q~BWOc1Y1tjHfS6iwMH~ZlahmZR_emNQYaiA")
